
	" 🏅 Ashwani [ Aimbot ] ",
	
  
function H2()
gg.setRanges(131108)
    var = gg.getResults(5000)
    gg.clearResults()
    gg.editAll("0",20)
    gg.clearResults()
    gg.setRanges(gg.REGION_BAD)
    gg.searchNumber("-88.66608428955;26:512",gg.POINTER_WRITABLE,false,gg.SIGN_FUZZY_EQUAL,0,-1)
    gg.searchNumber("26",gg.POINTER_WRITABLE,false,gg.SIGN_FUZZY_EQUAL,0,-1)
    var = gg.getResults(2)
    gg.editAll("-460",gg.POINTER_WRITABLE)
    gg.clearResults()
    gg.searchNumber("-88.73961639404;28:512",gg.POINTER_WRITABLE,false,gg.SIGN_FUZZY_EQUAL,0,-1)
    gg.searchNumber("28",gg.POINTER_WRITABLE,false,gg.SIGN_FUZZY_EQUAL,0,-1)
    var = gg.getResults(2)
    gg.editAll("-560",gg.POINTER_WRITABLE)
    gg.clearResults()
    gg.setRanges(gg.REGION_ANONYMOUS)
    gg.searchNumber("9.201618;30.5;25",gg.POINTER_WRITABLE,false,gg.SIGN_FUZZY_EQUAL,0,-1)
    gg.searchNumber("25;30.5",gg.POINTER_WRITABLE,false,gg.SIGN_FUZZY_EQUAL,0,-1)
    var = gg.getResults(10)
    gg.editAll("250",gg.POINTER_WRITABLE)
    gg.clearResults()
    gg.toast("headshot lobby ")
  end
  
function H3() 
gg.setRanges(32)
    gg.searchNumber("9.20161819458;23;25;30.5",16,false,536870912,0,-1)
    gg.searchNumber("25;30.5",16,false,536870912,0,-1)
    gg.getResults(10)
    gg.editAll("251",16)
    gg.toast("magic bullet activated")
    gg.clearResults()
  end
  

function H7()
  gg.clearResults()
    gg.setRanges(gg.REGION_ANONYMOUS)
    gg.searchNumber("0.20000000298~0.30000001192F;53.0F;30.0F;1.0F::512",gg.TYPE_FLOAT,false,gg.SIGN_EQUAL,0,-1)
    gg.searchNumber("0.20000000298~0.30000001192F;1.0F::512",gg.TYPE_FLOAT,false,gg.SIGN_EQUAL,0,-1)
    gg.getResults(200)
    gg.editAll("1.4012985e-45",gg.TYPE_FLOAT)
    gg.clearResults()
    gg.toast("no recoil ")
end

function H8() 
gg.clearResults()
    gg.setRanges(8)
    gg.searchNumber("360;0.0001;1478828288",16,false,536870912,0,-1)
    gg.searchNumber("0.0001",16,false,536870912,0,-1)
    gg.getResults(100)
    gg.editAll("9999",16)
    gg.toast("aimbot shortrange")
    gg.clearResults()
  end
  
function H9() 
gg.clearResults()
gg.setRanges(32)
gg.searchNumber("1;1;1;0.0001;20;0.0005;0.4::50", 16, false, 536870912, 0, -1)
gg.searchNumber("1", 16, false, 536870912, 0, -1)
gg.getResults(100)
gg.editAll("1.2,5", 16)
gg.toast("Ultra Speed Run ")
  end
  


